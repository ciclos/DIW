# ejemploKanbanBootstrap
Ejemplo de clase de uso de Bootstrap para crear un kanban
